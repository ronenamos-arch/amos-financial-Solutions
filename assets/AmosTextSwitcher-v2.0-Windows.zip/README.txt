AmosTextSwitcher v2.0
=====================

Fast and stable Hebrew-English text converter with template management.

INSTALLATION:
1. Make sure you have .NET 8 Desktop Runtime installed
   Download from: https://dotnet.microsoft.com/download/dotnet/8.0/runtime

2. Extract all files to a folder of your choice

3. Run AmosTextSwitcher.exe

USAGE:
- Press F10 to convert selected text between Hebrew and English
- Press F6 to swap upper/lower case
- Double-click the system tray icon for Quick Access window

FEATURES:
- Template management - Save frequently used text
- Quick Access window with search
- Import/Export templates
- Usage tracking
- Lightweight (~200KB)
- Stable and fast

Support: ronenamos@gmail.com
Website: https://ronenamos-arch.github.io/amos-financial-Solutions/

License: MIT
